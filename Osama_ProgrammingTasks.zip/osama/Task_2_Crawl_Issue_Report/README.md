
This program crawls and parse the following issue report:

https://issues.apache.org/jira/browse/CAMEL-10597

Specifically, It gets all properties of the issue CAMEL-10597


After data crawling all the important data is written in CSV file.

I have replaced some commas with : while csv file writing
