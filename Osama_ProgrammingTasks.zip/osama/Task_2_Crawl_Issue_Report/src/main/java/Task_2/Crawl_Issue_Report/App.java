package Task_2.Crawl_Issue_Report;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
        Crawler crawl = new Crawler();
        JIRAIssue issue =  crawl.CrawlIssueReport();
        crawl.WritingDataToCSV(issue);
    }
}
